---
title: StreamAnalytics
geekdocCollapseSection: true
geekdocHidden: false
---
