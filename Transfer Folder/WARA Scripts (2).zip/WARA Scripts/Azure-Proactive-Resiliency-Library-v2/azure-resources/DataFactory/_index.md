---
title: DataFactory
geekdocCollapseSection: true
geekdocHidden: true
---
