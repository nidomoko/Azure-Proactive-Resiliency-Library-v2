---
title: factories
geekdocCollapseSection: true
geekdocHidden: true
---

{{< azure-resources-recommendationlist name="azure-resources-recommendationlist" >}}
