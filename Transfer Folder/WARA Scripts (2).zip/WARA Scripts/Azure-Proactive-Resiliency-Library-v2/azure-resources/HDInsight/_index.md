---
title: HDInsight
geekdocCollapseSection: true
geekdocHidden: true
---
