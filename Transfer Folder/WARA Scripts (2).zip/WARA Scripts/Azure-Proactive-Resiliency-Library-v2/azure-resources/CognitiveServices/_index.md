---
title: CognitiveServices
geekdocCollapseSection: true
geekdocHidden: false
---
