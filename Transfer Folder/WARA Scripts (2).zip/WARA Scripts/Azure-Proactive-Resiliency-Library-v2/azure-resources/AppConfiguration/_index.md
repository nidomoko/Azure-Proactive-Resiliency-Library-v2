---
title: AppConfiguration
geekdocCollapseSection: true
geekdocHidden: false
---
