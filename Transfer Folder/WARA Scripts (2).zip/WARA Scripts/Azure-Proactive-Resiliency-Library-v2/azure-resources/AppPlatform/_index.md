---
title: AppPlatform
geekdocCollapseSection: true
geekdocHidden: true
---
