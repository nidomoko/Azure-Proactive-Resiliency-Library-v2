---
title: Azure Resources
weight: 20
geekdocCollapseSection: true
---

{{< toc-tree >}}
