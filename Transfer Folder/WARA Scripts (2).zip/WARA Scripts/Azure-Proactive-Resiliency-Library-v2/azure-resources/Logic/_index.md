---
title: Logic
geekdocCollapseSection: true
geekdocHidden: true
---
