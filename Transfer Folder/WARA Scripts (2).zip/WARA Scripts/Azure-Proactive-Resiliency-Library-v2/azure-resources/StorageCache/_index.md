---
title: StorageCache
geekdocCollapseSection: true
geekdocHidden: true
---
