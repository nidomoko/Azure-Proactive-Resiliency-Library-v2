---
title: Synapse
geekdocCollapseSection: true
geekdocHidden: true
---
