---
title: SAP on Azure
geekdocCollapseSection: true
geekdocHidden: false
---

Refer to:

- Azure Center for SAP Solutions
- Opensource Quality Checks
- Openssource Inventory Checks

## General Workload Guidance

{{< azure-specialized-workloads-recommendationlist name="azure-specialized-workloads-recommendationlist" >}}
