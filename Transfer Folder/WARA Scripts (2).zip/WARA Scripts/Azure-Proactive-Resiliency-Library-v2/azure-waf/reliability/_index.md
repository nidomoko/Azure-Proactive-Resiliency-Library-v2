---
title: Reliability
weight: 70
geekdocCollapseSection: true
geekdocHidden: false
---

This section contains all recommendations from the Azure Well-Architected Framework's Reliability pillar.

{{< azure-waf-recommendationlist name="azure-waf-recommendationlist" >}}
