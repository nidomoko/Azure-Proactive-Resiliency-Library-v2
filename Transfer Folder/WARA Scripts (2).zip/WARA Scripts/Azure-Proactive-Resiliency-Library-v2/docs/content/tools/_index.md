---
title: Tools
weight: 45
geekdocCollapseSection: true
---

This section lists of all of the information pertaining to the APRL tooling/scripts. The guidance is broken down into the following sections:

- [Collector Script Documentation](/Azure-Proactive-Resiliency-Library-v2/tools/collector)
- [Analyzer Script Documentation](/Azure-Proactive-Resiliency-Library-v2/tools/analyzer)
- [Reports Script Documentation](/Azure-Proactive-Resiliency-Library-v2/tools/reports)

{{< toc >}}
