---
name: "Feature request \U0001F4A1"
about: "Got an awesome idea to make these modules even better? Let us know \U0001F44D"
title: "\U0001F4A1 Feature Request - PLEASE CHANGE ME TO SOMETHING DESCRIPTIVE"
labels: enhancement
assignees: ''

---

## Describe the solution you'd like

A clear and concise description of your awesome idea to make these modules even better 👍

## Describe alternatives you've considered

A clear and concise description of any alternative solutions or features you've considered.

## Additional context

Add any other context or screenshots about the feature request here. 📷
